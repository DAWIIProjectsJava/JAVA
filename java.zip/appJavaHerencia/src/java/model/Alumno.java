/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author 100005978.joan23
 */
public class Alumno extends Persona {
    //Attributes
    private String matricula;
    private ArrayList<Double> notas;

    //Full constructor
    public Alumno(String matricula, ArrayList<Double> notas, String nombre, String apellidos, int edad, int telefono) {
        super(nombre, apellidos, edad, telefono);
        this.matricula = matricula;
        this.notas = notas;
    }
    
    //Empty constructor
    public Alumno() {
    }

    //Getters
    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public int getTelefono() {
        return telefono;
    }
    
    
}
